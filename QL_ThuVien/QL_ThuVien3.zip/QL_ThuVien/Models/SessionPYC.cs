﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QL_ThuVien.Models
{
    public class SessionPYC
    {
        public string TL_SoDangKyCaBiet { get; set; }

        public short? TL_TrangThai { get; set; }
    }
}