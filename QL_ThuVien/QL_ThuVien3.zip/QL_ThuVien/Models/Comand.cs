﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QL_ThuVien.Models
{
    public static class Comand
    {
        public static string NV_EMAIL { get; set; }
        public static string NV_ID { get; set; }
        public static int? NV_Level { get; set; }
        public static string NV_MATKHAU { get; set; }
    }
}